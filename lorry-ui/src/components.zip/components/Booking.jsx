import { useState } from "react";

function Booking() {

    const [formData, setFormData] = useState({
        name: '',
        mobile: '',
        date: '',
        goods: 'Food', // Default to 'Food' as it's the first option in the select dropdown
        origin: '',
        destination: '',
        amount: '',
        lorrynumber: '',
    });

    const handleChange = (e) => {
        setFormData({...formData, [e.target.name]: e.target.value});
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        fetch('http://localhost:4000/booking', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        })
        .then(response => response.json())
        .then(data => {
            console.log('Success:', data);
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    };

    return(
        <>
            <div className="booking-container">
                <h1>Book Transportation</h1>
                <form onSubmit={handleSubmit}>
                    <label>
                        Name
                        <input type="text" name="name" placeholder="Enter your name" onChange={handleChange} required/>
                    </label>
                    <label>
                        Mobile
                        <input type="text" name="mobile" placeholder="Enter your phone number" onChange={handleChange} />
                    </label>
                    <label>
                        Date
                        <input type="date" name="date" onChange={handleChange} required/>
                    </label>
                    <label>
                        Goods
                        <select name="goods" onChange={handleChange}>
                            <option>Food</option>
                            <option>Iron</option>
                            <option>Wood</option>
                            <option>Others</option>
                        </select>
                    </label>
                    <label>
                        Origin
                        <input type="text" name="origin" placeholder="Origin" onChange={handleChange} />
                    </label>
                    <label>
                        Destination
                        <input type="text" name="destination" placeholder="Destination" onChange={handleChange} />
                    </label>
                    <label>
                        Amount
                        <input type="text" name="amount" placeholder="Price" onChange={handleChange} required/>
                    </label>
                    <label>
                        Lorry Number
                        <select name="lorrynumber" onChange={handleChange} required>
                            <option>6049</option>
                            <option>6050</option>
                            <option>6051</option>
                            <option>6052</option>
                        </select>
                    </label>
                    <button type="submit">Book</button>
                </form>
            </div>
        </>
    )
}

export default Booking