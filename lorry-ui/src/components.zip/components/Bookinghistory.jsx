import React, { useState, useEffect } from 'react';


function Bookinghistory(){
    const [items, setItems] = useState([]);

  useEffect(() => {
    fetch('http://localhost:4000/bookinghistory/')
      .then(response => response.json())
      .then(data => setItems(data))
      .catch(err => console.error('Error fetching data: ', err));
  }, []);

  function formatDate(isoDateString) {
    return new Date(isoDateString).toLocaleDateString('en-GB'); // 'en-GB' uses day-month-year format (DD-MM-YYYY)
   }

  return (
    <div className="App">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
      <table className="table table-striped" id="tablee">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Mobile</th>
            <th scope="col">Date</th>
            <th scope="col">Goods</th>
            <th scope="col">Origin</th>
            <th scope="col">Destination</th>
            <th scope="col">Amount</th>
            <th scope="col">Lorry Number</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, index) => (
            <tr key={index}>
              <th scope="row">{index + 1}</th>
              <td>{item.name}</td>
              <td>{item.mobile}</td>
              <td>{formatDate(item.date)}</td>
              <td>{item.goods}</td>
              <td>{item.origin}</td>
              <td>{item.destination}</td>
              <td>{item.amount}</td>
              <td>{item.lorrynumber}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Bookinghistory